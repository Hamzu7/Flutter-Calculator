import 'package:flutter/material.dart';

const operatorColor = Color(0xff463b3b);
const buttonColor = Color(0xff686464);
const orangeColor = Colors.orange;
